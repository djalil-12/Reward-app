import React from 'react';

export const AppLogo: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg width="120" height="120" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <defs>
      <linearGradient id="logo-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#22d3ee" /> {/* cyan-400 */}
        <stop offset="100%" stopColor="#06b6d4" /> {/* cyan-500 */}
      </linearGradient>
      <filter id="logo-shadow" x="-20%" y="-20%" width="140%" height="140%">
        <feGaussianBlur in="SourceAlpha" stdDeviation="1.5" result="blur"/>
        <feOffset in="blur" dx="0" dy="1" result="offsetBlur"/>
        <feMerge>
          <feMergeNode in="offsetBlur"/>
          <feMergeNode in="SourceGraphic"/>
        </feMerge>
      </filter>
    </defs>
    <g filter="url(#logo-shadow)">
      <circle cx="12" cy="12" r="10" fill="url(#logo-gradient)" />
      <path d="M9.5 15.5V8.5L15.5 12L9.5 15.5Z" fill="white"/>
    </g>
  </svg>
);