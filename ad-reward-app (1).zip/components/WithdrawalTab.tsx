
import React, { useState } from 'react';
import type { Translations, WithdrawalRecord, User } from '../types';
import InfoModal from './InfoModal';
import { SpinnerIcon } from './icons/SpinnerIcon';

interface WithdrawalTabProps {
  balance: number;
  onAddWithdrawalRequest: (request: Omit<WithdrawalRecord, 'id' | 'date' | 'status'>) => void;
  t: Translations;
  user: User;
}

const MIN_WITHDRAWAL_POINTS = 100;

const WithdrawalTab: React.FC<WithdrawalTabProps> = ({ balance, onAddWithdrawalRequest, t, user }) => {
  const [amount, setAmount] = useState('');
  const [paypalEmail, setPaypalEmail] = useState('');
  const [message, setMessage] = useState('');
  const [isInfoModalOpen, setIsInfoModalOpen] = useState(false);
  const [infoModalMessage, setInfoModalMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const amountNumber = parseInt(amount, 10);
  
  const isEmailValid = () => paypalEmail.trim() !== '' && /\S+@\S+\.\S+/.test(paypalEmail);

  const isFormValid = () => {
    if (isNaN(amountNumber) || amountNumber < MIN_WITHDRAWAL_POINTS || amountNumber > balance) {
      return false;
    }
    if (!isEmailValid()) {
      return false;
    }
    return true;
  };
  
  const handleWithdraw = async () => {
    if (isNaN(amountNumber) || amountNumber <= 0) {
      setInfoModalMessage(t.invalidAmountNotice);
      setIsInfoModalOpen(true);
      return;
    }
    if (amountNumber < MIN_WITHDRAWAL_POINTS) {
      setInfoModalMessage(t.minWithdrawalNotice.replace('{amount}', MIN_WITHDRAWAL_POINTS.toString()));
      setIsInfoModalOpen(true);
      return;
    }
     if (amountNumber > balance) {
      setInfoModalMessage(t.insufficientBalanceNotice);
      setIsInfoModalOpen(true);
      return;
    }
    if (!isEmailValid()) {
       setInfoModalMessage(t.invalidDetailsNotice);
       setIsInfoModalOpen(true);
       return;
    }

    setIsLoading(true);
    setMessage('');
    try {
      const withdrawalData = {
        amount: amountNumber,
        method: 'paypal' as const,
        details: paypalEmail,
        userEmail: user.email,
      };
      
      // Send the withdrawal request to the backend server
      const response = await fetch('/api/create-withdrawal', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(withdrawalData),
      });

      if (!response.ok) {
        // Handle server errors (e.g., 500) or validation errors (e.g., 400)
        throw new Error('Server responded with an error');
      }

      // If the server request is successful, update the UI state
      onAddWithdrawalRequest(withdrawalData);

      const successMsg = t.withdrawalSuccessMessage
        .replace('{amount}', amountNumber.toString())
        .replace('{method}', 'PayPal');
      setMessage(successMsg);
      setAmount('');
      setPaypalEmail('');
      setTimeout(() => setMessage(''), 4000);

    } catch(error) {
      console.error("Withdrawal failed:", error);
      setInfoModalMessage(t.withdrawalError);
      setIsInfoModalOpen(true);
    } finally {
      setIsLoading(false);
    }
  };
  
  const isButtonActive = isFormValid();

  return (
    <>
      <div className="flex flex-col h-full max-w-md mx-auto">
        <h2 className="text-3xl font-bold mb-1 text-center text-white">{t.withdrawEarnings}</h2>
        <p className="text-sm text-gray-400 mb-4 text-center">{t.pointsConversionNote}</p>

        <div className="bg-gray-800 p-6 rounded-xl shadow-lg">
          <div className="mb-4">
            <label htmlFor="amount" className="block text-sm font-medium text-gray-300 mb-2">
              {t.withdrawalAmount} ({t.points})
            </label>
            <input
              id="amount"
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0"
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white text-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
              disabled={isLoading}
            />
          </div>
          
          <div className="mb-6">
            <label htmlFor="paypalEmail" className="block text-sm font-medium text-gray-300 mb-2">
              {t.paypalEmail}
            </label>
            <input
              id="paypalEmail"
              type="email"
              value={paypalEmail}
              onChange={(e) => setPaypalEmail(e.target.value)}
              placeholder={t.enterPayPalEmail}
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white text-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
              disabled={isLoading}
            />
          </div>


          <button
            onClick={handleWithdraw}
            disabled={!isButtonActive || isLoading}
            className={`w-full py-4 font-bold text-lg rounded-lg shadow-md transition-all duration-200 flex justify-center items-center ${isButtonActive && !isLoading ? 'bg-green-600 text-white hover:bg-green-500' : 'bg-gray-600 text-gray-400 cursor-not-allowed'}`}
          >
            {isLoading ? <SpinnerIcon className="w-6 h-6 animate-spin"/> : t.withdrawNow}
          </button>
          {message && <p className="mt-4 text-center text-green-400 font-semibold">{message}</p>}
        </div>
      </div>
      <InfoModal 
        isOpen={isInfoModalOpen}
        onClose={() => setIsInfoModalOpen(false)}
        message={infoModalMessage}
        t={t}
      />
    </>
  );
};

export default WithdrawalTab;