import React, { useEffect, useRef } from 'react';
import type { Translations, Language } from '../types';
import { AppLogo } from './icons/AppLogo';

// Define google object on window for TypeScript
declare global {
  interface Window {
    google: any;
  }
}

interface LoginScreenProps {
  onLogin: (userData: { name:string; email: string; imageUrl: string; }) => void;
  t: Translations;
  language: Language;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin, t, language }) => {
  const signInButtonRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleCredentialResponse = (response: any) => {
      try {
        const idToken = response.credential;
        const base64Url = idToken.split('.')[1];
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));

        const userData = JSON.parse(jsonPayload);
        
        onLogin({
          name: userData.name,
          email: userData.email,
          imageUrl: userData.picture,
        });
      } catch (error) {
        console.error("Error decoding JWT or handling login:", error);
      }
    };
    
    // Check if the Google script has loaded and the target element is available
    if (typeof window.google !== 'undefined' && signInButtonRef.current) {
        signInButtonRef.current.innerHTML = ''; // Clear previous button
        window.google.accounts.id.initialize({
          // NOTE: This client ID is a placeholder. For a real application, you must create your own
          // in the Google Cloud Console and configure its authorized JavaScript origins.
          client_id: "261028765391-0kp4pq5i9123bsvt2gao8sn5pe2nhdv4.apps.googleusercontent.com",
          callback: handleCredentialResponse,
        });

        window.google.accounts.id.renderButton(
          signInButtonRef.current,
          { 
            theme: "filled_blue", 
            size: "large", 
            type: 'standard', 
            text: 'signin_with', 
            shape: 'rectangular', 
            logo_alignment: 'left',
            locale: language,
            width: '280'
          }
        );
    }
  }, [onLogin, language]);


  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-gray-900">
      <div className="text-center">
        <AppLogo className="mb-8 mx-auto" />
        <h1 className="text-4xl font-bold text-white mb-2">{t.welcome}</h1>
        <p className="text-lg text-gray-400 mb-8">{t.loginPrompt}</p>
        <div ref={signInButtonRef} className="flex justify-center"></div>
         <p className="text-xs text-gray-500 mt-4 max-w-xs px-2">
           {t.adblockerNote}
        </p>
      </div>
    </div>
  );
};

export default LoginScreen;