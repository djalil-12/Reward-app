import React, { useState } from 'react';
import type { Translations, Language } from '../types';
import { BackIcon } from './icons/BackIcon';
import AdModal from './AdModal';

interface TasksTabProps {
  onBack: () => void;
  t: Translations;
  language: Language;
  onAddBalance: (amount: number) => void;
}

interface Task {
  id: string;
  textKey: string;
  requiredViews: number;
  reward: number;
}

const TasksTab: React.FC<TasksTabProps> = ({ onBack, t, language, onAddBalance }) => {
  const [taskProgress, setTaskProgress] = useState<{ [key: string]: number }>({});
  const [message, setMessage] = useState('');
  const [isAdModalOpen, setIsAdModalOpen] = useState(false);
  const [currentTask, setCurrentTask] = useState<Task | null>(null);

  const tasks: Task[] = [
    { id: 'task1', textKey: 'task1Title', requiredViews: 1, reward: 5 },
    { id: 'task2', textKey: 'task2Title', requiredViews: 2, reward: 10 },
    { id: 'task3', textKey: 'task3Title', requiredViews: 5, reward: 30 },
  ];

  const handleWatchAdClick = (task: Task) => {
    setCurrentTask(task);
    setIsAdModalOpen(true);
  };

  const handleAdComplete = () => {
    if (!currentTask) return;

    if (currentTask.requiredViews === 1) {
      onAddBalance(currentTask.reward);
      setMessage(t.rewardClaimedMessage.replace('{points}', currentTask.reward.toString()));
      setTimeout(() => setMessage(''), 3000);
    } else {
      const newProgress = (taskProgress[currentTask.id] || 0) + 1;
      setTaskProgress(prev => ({ ...prev, [currentTask.id]: newProgress }));
    }
    setCurrentTask(null); // Reset after processing
  };

  const handleClaimReward = (task: Task) => {
    onAddBalance(task.reward);
    setMessage(t.rewardClaimedMessage.replace('{points}', task.reward.toString()));
    setTimeout(() => setMessage(''), 3000);
    setTaskProgress(prev => ({ ...prev, [task.id]: 0 }));
  };

  return (
    <>
      <div className="flex flex-col h-full animate-fade-in">
        <header className="flex items-center mb-6 -mx-4 -mt-4 px-4 pt-4">
          <div className="flex-1">
            <button onClick={onBack} className="p-2 rounded-full hover:bg-gray-700 transition-colors">
              <BackIcon className={`w-6 h-6 ${language === 'ar' ? 'transform scale-x-[-1]' : ''}`} />
            </button>
          </div>
          <h2 className="text-2xl font-bold text-white text-center flex-1">{t.tasks}</h2>
          <div className="flex-1"></div>
        </header>

        <div className="flex-1 flex flex-col space-y-3">
          {tasks.map(task => {
            const progress = taskProgress[task.id] || 0;
            const isComplete = progress >= task.requiredViews;

            return (
              <div key={task.id} className="bg-gray-800 p-4 rounded-lg flex items-center justify-between shadow-md">
                <span className="text-lg font-medium text-white flex-1">{t[task.textKey]}</span>
                {isComplete && task.requiredViews > 1 ? (
                  <button
                    onClick={() => handleClaimReward(task)}
                    className="px-4 py-2 bg-green-600 text-white font-semibold rounded-lg shadow-md hover:bg-green-500 transition-colors"
                  >
                    {t.claimReward}
                  </button>
                ) : (
                  <button
                    onClick={() => handleWatchAdClick(task)}
                    className="px-4 py-2 bg-cyan-600 text-white font-semibold rounded-lg shadow-md hover:bg-cyan-500 transition-colors whitespace-nowrap"
                  >
                    {task.requiredViews > 1 ? `${t.watch} (${progress}/${task.requiredViews})` : t.watch}
                  </button>
                )}
              </div>
            );
          })}
        </div>

        {message && <p className="mt-4 text-center text-green-400 font-semibold">{message}</p>}

        <style>{`
          @keyframes fade-in {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
          }
          .animate-fade-in {
            animation: fade-in 0.3s ease-out forwards;
          }
        `}</style>
      </div>
      <AdModal
        isOpen={isAdModalOpen}
        onClose={() => setIsAdModalOpen(false)}
        onComplete={handleAdComplete}
        t={t}
      />
    </>
  );
};

export default TasksTab;