import React, { useState } from 'react';
import { PlayIcon } from './icons/PlayIcon';
import type { Translations } from '../types';
import { TasksIcon } from './icons/TasksIcon';
import AdModal from './AdModal';

interface EarningsTabProps {
  onAddBalance: (amount: number) => void;
  t: Translations;
  onNavigateToTasks: () => void;
}

const EarningsTab: React.FC<EarningsTabProps> = ({ onAddBalance, t, onNavigateToTasks }) => {
  const [message, setMessage] = useState('');
  const [isAdModalOpen, setIsAdModalOpen] = useState(false);

  const handleWatchAd = () => {
    setMessage('');
    setIsAdModalOpen(true);
  };
  
  const handleAdComplete = () => {
    const reward = 5; // Reward is now 5 points
    onAddBalance(reward);
    setMessage(t.congratsMessage.replace('{points}', reward.toString()));
    setTimeout(() => setMessage(''), 3000); // Clear message after 3 seconds
  };

  return (
    <>
      <div className="flex flex-col items-center justify-center h-full text-center">
        <h2 className="text-3xl font-bold mb-4 text-white">{t.earnRewardsTitle}</h2>
        <p className="text-gray-400 mb-8 max-w-sm">
          {t.earnRewardsDescription}
        </p>
        <div className="w-full max-w-xs space-y-4">
          <button
            onClick={handleWatchAd}
            disabled={isAdModalOpen}
            className="flex items-center justify-center w-full px-8 py-4 bg-cyan-500 text-white font-bold text-lg rounded-full shadow-lg transform hover:scale-105 transition-transform duration-300 disabled:bg-cyan-700 disabled:cursor-not-allowed"
          >
            <PlayIcon className="w-6 h-6 mx-3" />
            <span>{t.watchAdsButton}</span>
          </button>
          <button
            onClick={onNavigateToTasks}
            className="flex items-center justify-center w-full px-8 py-4 bg-purple-600 text-white font-bold text-lg rounded-full shadow-lg transform hover:scale-105 transition-transform duration-300"
          >
            <TasksIcon className="w-6 h-6 mx-3" />
            <span>{t.tasks}</span>
          </button>
        </div>
        {message && <p className="mt-6 text-green-400 font-semibold">{message}</p>}
      </div>
      <AdModal
        isOpen={isAdModalOpen}
        onClose={() => setIsAdModalOpen(false)}
        onComplete={handleAdComplete}
        t={t}
        adUrl="https://www.effectivegatecpm.com/aibuwu5xtp?key=385d728abc81993b97f7e9fcf8fa590c"
      />
    </>
  );
};

export default EarningsTab;