import React, { useState, useEffect } from 'react';
import type { Translations } from '../types';
import { SpinnerIcon } from './icons/SpinnerIcon';
import { CloseIcon } from './icons/CloseIcon';

const AD_DURATION_SECONDS = 5;

interface AdModalProps {
  isOpen: boolean;
  onClose: () => void;
  onComplete: () => void;
  t: Translations;
  adUrl?: string;
}

const AdModal: React.FC<AdModalProps> = ({ isOpen, onClose, onComplete, t, adUrl }) => {
  const [adState, setAdState] = useState<'loading' | 'playing'>('loading');
  const [countdown, setCountdown] = useState(AD_DURATION_SECONDS);

  useEffect(() => {
    if (isOpen) {
      // Reset state on open
      setAdState('loading');
      setCountdown(AD_DURATION_SECONDS);

      const loadingTimer = setTimeout(() => {
        setAdState('playing');
      }, 1500); // Simulate loading

      return () => clearTimeout(loadingTimer);
    }
  }, [isOpen]);

  useEffect(() => {
    if (adState === 'playing' && isOpen) {
      if (countdown > 0) {
        const countdownTimer = setTimeout(() => {
          setCountdown(prev => prev - 1);
        }, 1000);
        return () => clearTimeout(countdownTimer);
      } else {
        // Ad finished, grant reward and close modal immediately
        onComplete();
        onClose();
      }
    }
  }, [adState, countdown, isOpen, onComplete, onClose]);

  if (!isOpen) {
    return null;
  }

  const renderContent = () => {
    switch (adState) {
      case 'loading':
        return (
          <div className="bg-gray-800 rounded-2xl shadow-xl w-full max-w-sm text-white flex flex-col items-center justify-center text-center p-8">
            <SpinnerIcon className="w-12 h-12 text-cyan-400 animate-spin" />
            <p className="mt-4 text-xl">{t.loadingAd}</p>
          </div>
        );
      case 'playing':
        if (adUrl) {
          return (
            <div className="w-full h-full flex flex-col bg-gray-900">
               <div className="w-full h-1.5 bg-gray-700">
                <div
                  className="h-full bg-cyan-400 transition-all duration-1000 linear"
                  style={{ width: `${((AD_DURATION_SECONDS - countdown) / AD_DURATION_SECONDS) * 100}%` }}
                ></div>
              </div>
              <div className="flex-1 relative">
                 <iframe
                  src={adUrl}
                  className="w-full h-full border-0"
                  title="Advertisement"
                  sandbox="allow-scripts allow-same-origin allow-forms"
                ></iframe>
                <button
                  onClick={onClose}
                  className="absolute top-2 right-2 z-10 p-2 rounded-full bg-black bg-opacity-50 hover:bg-opacity-75 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled={countdown > 0}
                >
                  <CloseIcon className="w-6 h-6 text-white" />
                </button>
              </div>
            </div>
          );
        }
        // Fallback for non-iframe ads
        return (
          <div className="bg-gray-800 rounded-2xl shadow-xl w-full max-w-sm text-white flex flex-col items-center justify-center text-center p-8 relative">
            <button
              onClick={onClose}
              className="absolute top-2 right-2 z-10 p-2 rounded-full hover:bg-gray-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              disabled={countdown > 0}
            >
              <CloseIcon className="w-6 h-6 text-gray-400" />
            </button>
             <div className="w-full h-4 bg-gray-600 rounded-full overflow-hidden mb-4">
              <div
                className="h-full bg-green-500 transition-all duration-1000 linear"
                style={{ width: `${((AD_DURATION_SECONDS - countdown) / AD_DURATION_SECONDS) * 100}%` }}
              ></div>
            </div>
            <p className="text-xl">{t.watchingAd}</p>
          </div>
        );
    }
  };

  return (
    <div className="fixed inset-0 bg-gray-900 z-50 flex items-center justify-center animate-fade-in-fast">
      {renderContent()}
      <style>{`
        @keyframes fade-in-fast {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        .animate-fade-in-fast {
          animation: fade-in-fast 0.2s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default AdModal;