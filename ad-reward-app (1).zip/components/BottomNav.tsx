
import React from 'react';
import { Tab, Translations } from '../types';
import { MoneyIcon } from './icons/MoneyIcon';
import { WithdrawIcon } from './icons/WithdrawIcon';
import { HistoryIcon } from './icons/HistoryIcon';

interface BottomNavProps {
  activeTab: Tab;
  onTabChange: (tab: Tab) => void;
  t: Translations;
}

const BottomNav: React.FC<BottomNavProps> = ({ activeTab, onTabChange, t }) => {
  const navItems = [
    { id: Tab.Earnings, label: t.earnings, icon: MoneyIcon },
    { id: Tab.Withdrawal, label: t.withdrawal, icon: WithdrawIcon },
    { id: Tab.History, label: t.history, icon: HistoryIcon },
  ];

  return (
    <nav className="sticky bottom-0 left-0 right-0 bg-gray-800 shadow-t-lg z-20">
      <div className="flex justify-around max-w-md mx-auto">
        {navItems.map(item => (
          <button
            key={item.id}
            onClick={() => onTabChange(item.id)}
            className={`flex flex-col items-center justify-center flex-1 py-3 px-2 text-sm font-medium transition-colors duration-200 ${
              activeTab === item.id ? 'text-cyan-400' : 'text-gray-400 hover:text-white'
            }`}
          >
            <item.icon className="w-6 h-6 mb-1" />
            <span>{item.label}</span>
            {activeTab === item.id && <div className="w-8 h-1 bg-cyan-400 rounded-full mt-1"></div>}
          </button>
        ))}
      </div>
    </nav>
  );
};

export default BottomNav;
