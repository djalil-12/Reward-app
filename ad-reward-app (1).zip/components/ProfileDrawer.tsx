
import React, { useState, useEffect, useCallback } from 'react';
import type { User, Language, Translations } from '../types';
import { CloseIcon } from './icons/CloseIcon';
import { SettingsIcon } from './icons/SettingsIcon';
import { InfoIcon } from './icons/InfoIcon';
import { ContactIcon } from './icons/ContactIcon';
import SettingsModal from './SettingsModal';

interface ProfileDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  user: User;
  onUpdateUser: (updatedUser: Partial<User>) => void;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  t: Translations;
}

const ProfileDrawer: React.FC<ProfileDrawerProps> = ({ isOpen, onClose, user, onUpdateUser, language, onLanguageChange, t }) => {
  const [name, setName] = useState(user.name);
  const [isEditing, setIsEditing] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  useEffect(() => {
    setName(user.name);
  }, [user.name]);

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setName(e.target.value);
  };

  const handleNameSave = useCallback(() => {
    if (name.trim() === '') {
      setName(user.name);
    } else {
      onUpdateUser({ name });
    }
    setIsEditing(false);
  }, [name, user.name, onUpdateUser]);

  return (
    <>
      <div
        className={`fixed inset-0 bg-black bg-opacity-60 z-30 transition-opacity duration-300 ${
          isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={onClose}
      ></div>
      <div
        className={`fixed top-0 h-full w-72 bg-gray-800 shadow-2xl z-40 transform transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : (language === 'ar' ? 'translate-x-full' : '-translate-x-full')
        }`}
        style={{ left: language === 'en' ? '0' : 'auto', right: language === 'ar' ? '0' : 'auto' }}
      >
        <div className="flex flex-col h-full p-4">
          <div className="flex justify-end mb-4">
            <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-700 transition-colors">
              <CloseIcon className="w-6 h-6 text-gray-300" />
            </button>
          </div>
          
          <div className="flex flex-col items-center text-center">
            <img src={user.imageUrl} alt="Profile" className="w-24 h-24 rounded-full border-4 border-cyan-400 mb-4" />
            {isEditing ? (
              <input 
                type="text"
                value={name}
                onChange={handleNameChange}
                onBlur={handleNameSave}
                onKeyDown={(e) => e.key === 'Enter' && handleNameSave()}
                autoFocus
                className="w-full text-center bg-gray-700 text-white text-xl font-semibold rounded px-2 py-1"
              />
            ) : (
              <h2 onClick={() => setIsEditing(true)} className="text-xl font-semibold cursor-pointer p-1">
                {user.name}
              </h2>
            )}
            <p className="text-sm text-gray-400 mt-1">{user.email}</p>
          </div>

          <nav className="mt-10 flex-1">
            <ul className="space-y-2">
               <li>
                <button 
                  onClick={() => setIsSettingsOpen(true)}
                  className="w-full flex items-center p-3 text-gray-300 rounded-lg hover:bg-gray-700 hover:text-white transition-colors duration-200"
                >
                  <SettingsIcon className="w-6 h-6 me-4 text-cyan-400" />
                  <span className="font-medium">{t.settings}</span>
                </button>
              </li>
              <MenuItem icon={InfoIcon} label={t.howItWorks} />
              <MenuItem icon={ContactIcon} label={t.contactSupport} />
            </ul>
          </nav>
        </div>
      </div>
      <SettingsModal 
        isOpen={isSettingsOpen} 
        onClose={() => setIsSettingsOpen(false)}
        user={user}
        onUpdateUser={onUpdateUser}
        language={language}
        onLanguageChange={onLanguageChange}
        t={t}
      />
    </>
  );
};

interface MenuItemProps {
  icon: React.ElementType;
  label: string;
}
const MenuItem: React.FC<MenuItemProps> = ({ icon: Icon, label }) => (
  <li>
    <a href="#" className="flex items-center p-3 text-gray-300 rounded-lg hover:bg-gray-700 hover:text-white transition-colors duration-200">
      <Icon className="w-6 h-6 me-4 text-cyan-400" />
      <span className="font-medium">{label}</span>
    </a>
  </li>
);


export default ProfileDrawer;