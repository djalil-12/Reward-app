
import React, { useState } from 'react';
import type { User, Language, Translations, WithdrawalRecord } from '../types';
import { Tab } from '../types';
import EarningsTab from './EarningsTab';
import WithdrawalTab from './WithdrawalTab';
import BottomNav from './BottomNav';
import ProfileDrawer from './ProfileDrawer';
import { UserIcon } from './icons/UserIcon';
import TasksTab from './TasksTab';
import HistoryTab from './HistoryTab';

interface MainScreenProps {
  user: User;
  balance: number;
  withdrawals: WithdrawalRecord[];
  onUpdateUser: (updatedUser: Partial<User>) => void;
  onAddBalance: (amount: number) => void;
  onAddWithdrawalRequest: (request: Omit<WithdrawalRecord, 'id' | 'date' | 'status'>) => void;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  t: Translations;
}

const MainScreen: React.FC<MainScreenProps> = ({ 
  user, 
  balance, 
  withdrawals,
  onUpdateUser, 
  onAddBalance, 
  onAddWithdrawalRequest,
  language,
  onLanguageChange,
  t
}) => {
  const [activeTab, setActiveTab] = useState<Tab>(Tab.Earnings);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isTasksView, setIsTasksView] = useState(false);

  const handleTabChange = (tab: Tab) => {
    setIsTasksView(false); // Reset to default view when switching tabs
    setActiveTab(tab);
  };

  const renderActiveTab = () => {
    if (isTasksView && activeTab === Tab.Earnings) {
      return (
        <TasksTab 
          onBack={() => setIsTasksView(false)} 
          t={t} 
          language={language} 
          onAddBalance={onAddBalance}
        />
      );
    }

    switch (activeTab) {
      case Tab.Earnings:
        return (
          <EarningsTab 
            onAddBalance={onAddBalance} 
            t={t} 
            onNavigateToTasks={() => setIsTasksView(true)}
          />
        );
      case Tab.Withdrawal:
        return <WithdrawalTab user={user} balance={balance} onAddWithdrawalRequest={onAddWithdrawalRequest} t={t} />;
      case Tab.History:
        return <HistoryTab withdrawals={withdrawals} t={t} language={language} />;
      default:
        return null;
    }
  };

  return (
    <div className="relative flex flex-col h-screen max-h-screen overflow-hidden bg-gray-900 text-white">
      <ProfileDrawer 
        isOpen={isProfileOpen} 
        onClose={() => setIsProfileOpen(false)} 
        user={user} 
        onUpdateUser={onUpdateUser} 
        language={language}
        onLanguageChange={onLanguageChange}
        t={t}
      />
      
      <header className="flex items-center justify-between p-4 bg-gray-800 shadow-lg z-10">
        <button onClick={() => setIsProfileOpen(true)} className="p-2 rounded-full hover:bg-gray-700 transition-colors">
          <UserIcon className="w-6 h-6" />
        </button>
        <div className="text-lg font-bold bg-green-500 text-white px-4 py-1 rounded-full">
          {balance} {t.points}
        </div>
      </header>

      <main className="flex-1 overflow-y-auto p-4 md:p-6">
        {renderActiveTab()}
      </main>

      <BottomNav activeTab={activeTab} onTabChange={handleTabChange} t={t} />
    </div>
  );
};

export default MainScreen;