
import React, { useState, useEffect } from 'react';
import type { User, Language, Translations } from '../types';
import { CloseIcon } from './icons/CloseIcon';
import { PhoneIcon } from './icons/PhoneIcon';
import { CheckCircleIcon } from './icons/CheckCircleIcon';
import { SpinnerIcon } from './icons/SpinnerIcon';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User;
  onUpdateUser: (updatedUser: Partial<User>) => void;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  t: Translations;
}

type VerificationStatus = 'idle' | 'sending' | 'sent' | 'verifying' | 'verified';

const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, user, onUpdateUser, language, onLanguageChange, t }) => {
  const [phone, setPhone] = useState(user.phone || '');
  const [verificationCode, setVerificationCode] = useState('');
  const [status, setStatus] = useState<VerificationStatus>(user.isPhoneVerified ? 'verified' : 'idle');
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (isOpen) {
      setPhone(user.phone || '');
      setStatus(user.isPhoneVerified ? 'verified' : 'idle');
      setMessage('');
      setVerificationCode('');
    }
  }, [isOpen, user]);

  if (!isOpen) return null;
  
  const handleSavePhone = () => {
    onUpdateUser({ phone, isPhoneVerified: false });
    setMessage(t.phoneSavedSuccess);
    setStatus('idle');
    setTimeout(() => setMessage(''), 3000);
  };
  
  const handleSendCode = () => {
    setStatus('sending');
    setMessage(t.sendingCode);
    setTimeout(() => {
      setStatus('sent');
      setMessage(t.codeSent);
    }, 2000);
  };
  
  const handleVerifyCode = () => {
    setStatus('verifying');
    setMessage(t.verifyingCode);
    if (verificationCode.length === 4 && /^\d+$/.test(verificationCode)) {
      setTimeout(() => {
        onUpdateUser({ isPhoneVerified: true });
        setStatus('verified');
        setMessage(t.phoneVerifiedSuccess);
        setVerificationCode('');
        setTimeout(() => setMessage(''), 3000);
      }, 2000);
    } else {
      setTimeout(() => {
        setStatus('sent');
        setMessage(t.invalidCode);
      }, 2000);
    }
  };

  const isPhoneUnchanged = phone === user.phone;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-gray-800 rounded-2xl shadow-xl w-full max-w-md text-white p-6 relative animate-fade-in-up" onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} className={`absolute top-4 p-2 rounded-full hover:bg-gray-700 transition-colors ${language === 'ar' ? 'left-4' : 'right-4'}`}>
          <CloseIcon className="w-6 h-6 text-gray-300" />
        </button>
        <h2 className="text-2xl font-bold mb-6 text-center">{t.settings}</h2>

        <div className="mb-6">
          <h3 className="text-lg font-semibold mb-3 text-gray-300">{t.language}</h3>
          <div className="flex gap-2">
            <button 
              onClick={() => onLanguageChange('ar')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${language === 'ar' ? 'bg-cyan-500 text-white' : 'bg-gray-700 hover:bg-gray-600'}`}
            >
              العربية
            </button>
            <button
               onClick={() => onLanguageChange('en')}
               className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${language === 'en' ? 'bg-cyan-500 text-white' : 'bg-gray-700 hover:bg-gray-600'}`}
            >
              English
            </button>
          </div>
        </div>
        
        <div>
          <h3 className="text-lg font-semibold mb-3 text-gray-300">{t.phoneNumber}</h3>
          <div className="space-y-4">
            <div className="relative">
              <PhoneIcon className={`absolute top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 ${language === 'ar' ? 'right-3' : 'left-3'}`} />
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder={t.enterPhoneNumber}
                className={`w-full bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition ${language === 'ar' ? 'pr-10 pl-4' : 'pl-10 pr-4'} py-3`}
                disabled={status !== 'idle' || user.isPhoneVerified}
              />
            </div>
            
            {status === 'idle' && !isPhoneUnchanged && (
              <button onClick={handleSavePhone} className="w-full py-3 bg-cyan-600 rounded-lg font-semibold hover:bg-cyan-500 transition">
                {t.saveNumber}
              </button>
            )}

            {status === 'idle' && user.phone && isPhoneUnchanged && !user.isPhoneVerified && (
              <button onClick={handleSendCode} className="w-full py-3 bg-green-600 rounded-lg font-semibold hover:bg-green-500 transition">
                {t.verifyNumber}
              </button>
            )}

            {status === 'verified' && (
              <div className="flex items-center justify-center gap-2 text-green-400 bg-green-900/50 py-2 px-4 rounded-lg">
                <CheckCircleIcon className="w-5 h-5" />
                <span className="font-medium">{t.numberVerified}: {user.phone}</span>
              </div>
            )}
            
            {(status === 'sending' || status === 'verifying') && (
              <div className="flex items-center justify-center gap-2 text-cyan-300 py-2">
                <SpinnerIcon className="w-5 h-5 animate-spin"/>
                <span className="font-medium">{message}</span>
              </div>
            )}

            {status === 'sent' && (
              <div className="p-4 bg-gray-900/50 rounded-lg">
                <p className="text-center text-sm text-gray-300 mb-3">{message}</p>
                <input
                  type="text"
                  value={verificationCode}
                  onChange={(e) => setVerificationCode(e.target.value)}
                  placeholder={t.enterVerificationCode}
                  maxLength={4}
                  className="w-full text-center tracking-widest text-lg px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
                />
                 <button onClick={handleVerifyCode} className="w-full mt-3 py-3 bg-green-600 rounded-lg font-semibold hover:bg-green-500 transition">
                    {t.confirm}
                </button>
              </div>
            )}

            {message && status !== 'sending' && status !== 'verifying' && status !== 'sent' && <p className="text-center text-sm text-green-400">{message}</p>}
            
          </div>
        </div>
      </div>
      <style>{`
        @keyframes fade-in-up {
          from { opacity: 0; transform: scale(0.95) translateY(20px); }
          to { opacity: 1; transform: scale(1) translateY(0); }
        }
        .animate-fade-in-up {
          animation: fade-in-up 0.3s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default SettingsModal;