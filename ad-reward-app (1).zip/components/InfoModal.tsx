
import React from 'react';
import type { Translations } from '../types';
import { CloseIcon } from './icons/CloseIcon';

interface InfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  message: string;
  t: Translations;
}

const InfoModal: React.FC<InfoModalProps> = ({ isOpen, onClose, message, t }) => {
  if (!isOpen) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-gray-800 rounded-2xl shadow-xl w-full max-w-sm text-white p-6 relative animate-fade-in-up" onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} className="absolute top-4 right-4 p-2 rounded-full hover:bg-gray-700 transition-colors">
          <CloseIcon className="w-6 h-6 text-gray-300" />
        </button>
        <h2 className="text-xl font-bold mb-4 text-cyan-400">{t.notice}</h2>
        <p className="text-gray-300 mb-6">{message}</p>
        <button
          onClick={onClose}
          className="w-full py-3 bg-cyan-600 text-white font-semibold rounded-lg shadow-md hover:bg-cyan-500 transition-colors"
        >
          {t.ok}
        </button>
      </div>
      <style>{`
        @keyframes fade-in-up {
          from { opacity: 0; transform: scale(0.95) translateY(20px); }
          to { opacity: 1; transform: scale(1) translateY(0); }
        }
        .animate-fade-in-up {
          animation: fade-in-up 0.3s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default InfoModal;
