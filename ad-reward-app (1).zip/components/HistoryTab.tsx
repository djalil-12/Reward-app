
import React from 'react';
import type { Translations, WithdrawalRecord, Language } from '../types';
import { InfoIcon } from './icons/InfoIcon';

interface HistoryTabProps {
  withdrawals: WithdrawalRecord[];
  t: Translations;
  language: Language;
}

const StatusBadge: React.FC<{ status: 'pending' | 'completed'; t: Translations }> = ({ status, t }) => {
  const baseClasses = "px-3 py-1 text-xs font-bold rounded-full";
  const statusClasses = {
    pending: "bg-yellow-500/20 text-yellow-300",
    completed: "bg-green-500/20 text-green-300",
  };
  return (
    <span className={`${baseClasses} ${statusClasses[status]}`}>
      {t[status]}
    </span>
  );
};

const HistoryTab: React.FC<HistoryTabProps> = ({ withdrawals, t, language }) => {
  const formatDate = (dateString: string) => {
    return new Intl.DateTimeFormat(language, { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    }).format(new Date(dateString));
  };

  return (
    <div className="flex flex-col h-full animate-fade-in">
      <h2 className="text-3xl font-bold mb-6 text-center text-white">{t.withdrawalHistory}</h2>
      
      {withdrawals.length === 0 ? (
        <div className="flex flex-col items-center justify-center flex-1 text-center text-gray-500">
          <InfoIcon className="w-16 h-16 mb-4" />
          <p className="text-lg">{t.noWithdrawals}</p>
        </div>
      ) : (
        <div className="space-y-4 overflow-y-auto">
          {withdrawals.map((item) => (
            <div key={item.id} className="bg-gray-800 p-4 rounded-lg shadow-md flex items-center justify-between">
              <div className="flex-1">
                <p className="font-bold text-lg text-white">
                  {item.amount} {t.points}
                </p>
                <p className="text-sm text-gray-400">
                  {t.viaPayPal}
                </p>
                 <p className="text-xs text-gray-500 mt-1">{formatDate(item.date)}</p>
              </div>
              <div className="flex flex-col items-end">
                <StatusBadge status={item.status} t={t} />
              </div>
            </div>
          ))}
        </div>
      )}

      <style>{`
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: fade-in 0.3s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default HistoryTab;