// Filename: server/withdrawal.js
// This file contains the server-side logic for handling withdrawal requests.
// It should be run in a Node.js environment and is NOT part of the client-side bundle.

// You will need to install these dependencies on your server:
// npm install express firebase-admin cors
const express = require('express');
const admin = require('firebase-admin');
const cors = require('cors');

const app = express();

// Middleware
app.use(cors()); // Enable CORS for all routes
app.use(express.json()); // Enable parsing of JSON request bodies

// --- Firebase Admin SDK Configuration ---
// IMPORTANT: In a production environment, do NOT hardcode your credentials.
// Use environment variables or a secure secret manager.
const serviceAccount = {
  "type": "service_account",
  "project_id": "reward-8aee9",
  "private_key_id": "0604c569d496df640c4be94f49135058b78c56a2",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQDITsH2J2k5Typd\ncxz5vbcitRbqGVHY+y8XJDQjkWVP63FvR8N0HeOYmR6AKYCu2W9Qd3E/nMKrJOwK\nn4JV2Vx4yBUIbpzoyHj3g2CZUtAWFgoHVbd1ukxfFvPD5lNkPap9/9R668u8YWuG\nRX0iD8m93RCBJQUP0heDd/88RlrVCa4+aTTzuwA1xSLWe1HPgpxOWXFMuhQxchYR\nvoj94VdhYyJiFfUAcpmPuOhlkAWJ4tqR/QPelTY3bsGkiveVcpSkAPbEdu9g/aUG\n8++WzrZRWxnlWCadSE8F89gtsS++CZJirw+5Mc5j46nKvHLrr4D+1CQSsBCV7GPv\n0yAAqKoDAgMBAAECggEABOu6ZBuvwBKrzcPoMFJyz013lKSumBADpiPjjAQkYwQ7\nsyomKRIa50LLtwZN/P2meGmWxKNLPP0ZN2GXyBgg526y5ZQiEq3qGtqFYv7f0csU\nz/1RFnlPKv7bWjKsVcgWCiZgx+xHAwe5poDKhC2zHRDzONj5+NuGbFpkUMzBqn4Z\nNXC3nLWBB2S7MYmxIT7CLcAzqLB7QsPFnBWfgpn0KTpg7eU1zN1pf/DJHIZ6klFs\n16Abin2rWfWWqQCfqk2h6cJNM2i1Fx+W4nBwQaZVN3ngPZ//COsQfCDeSgNHw0NU\ndvGgtpXp0HyOBM+f6dhgu+8o28cNjaWPtH4IAJ+i8QKBgQD6ChJ+avr1ZsscFvaR\nZy72I4BZsak7QzAOKgRMJd0TNw/m1OCVVO3S/hNvZJGC9hHpLSk7RSx11vu4ecDX\nYQh3Zh7K2V18JsZa5UaGb8aHYO9UsQbKvSv+81bioArcP7NkD7WIsTbJckAg78+p\nsUY/RQDZrxJqmCzWq1QR1+lQpwKBgQDNFS9uHltGIlWFRjcM5kcFLA8/iJlIWtqe\nB6aV2gKOEwY/pGa2yyCLNBr4UYQ4CSnNSplm39DEQH+oZbxYWHYqDxn9N2/evhVC\n0A5LPsoIfXHbi2pggA4Y3e0ILQraj/i6hij3QXDwNaKADTpEELSIl9Ce1NeiEFVw\nUeUPAlNLRQKBgQCLhvFZACO4qzruGtZOv1CSY68s3hn8ivqW/NVXFM3v+grymZoV\nWsY3tjZsM6eLd/r4ro3SmEA+JdBj2fVFes05q4/FTFSBgjWv5T9cp6UWSH5lOT/8\nBGI3q9yxK/PDgfx9+tInTBSxhwLIHmo4XEdB6SSXVL2nI/HpfMO2DVESAwKBgQDB\nfFZWV0+X2LbE2Z0Aj5W7vHjaYT70s7sEU4WIZbn5XtuLWckKdpRKoSs80nOjBooo\nxFP8afcl4RBPyUQsObGqNrs3WoEyLjYS5gZGWYP1BJ1SG7OOPeKO9Xo3N3/A+woY\nuJCXzmcGSiP5GgG5y+T35fuOjpKutShWov0v7uq03QKBgQDCpeMHLTBRb30td9ZZ\nFCvJbsvBHA2XfEN5/yPncxLy1rIjus5VQW0/tIT9aBqvhhBafgQG2BQMxZeL6Ql7\n4NCEuEjb9O/IL6F9tFhT0/J2w+1UxpXUzWHoMVtqbS8T0AEvB/B/lC1O71A2dffR\n/LlJXXBpU4G6o1lf+gPmMN5wEQ==\n-----END PRIVATE KEY-----\n",
  "client_email": "firebase-adminsdk-fbsvc@reward-8aee9.iam.gserviceaccount.com",
  "client_id": "111419299954004359647",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-fbsvc%40reward-8aee9.iam.gserviceaccount.com",
  "universe_domain": "googleapis.com"
};

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

const db = admin.firestore();

// --- API Endpoint ---
// This endpoint receives withdrawal requests from the frontend app.
// The frontend will call this endpoint at the path `/api/create-withdrawal`
app.post('/api/create-withdrawal', async (req, res) => {
  try {
    const { amount, method, details, userEmail } = req.body;

    // Basic server-side validation
    if (!amount || amount < 100 || method !== 'paypal' || !details || !userEmail) {
      return res.status(400).json({ success: false, error: 'Invalid input data.' });
    }

    const withdrawalData = {
      amount: Number(amount),
      method,
      details,
      userEmail,
      status: 'pending',
      date: new Date().toISOString(),
    };

    const docRef = await db.collection('withdrawals').add(withdrawalData);

    console.log('Withdrawal request saved to Firebase with ID: ', docRef.id);
    return res.status(200).json({ success: true, id: docRef.id });

  } catch (error) {
    console.error('Error writing document to Firebase: ', error);
    return res.status(500).json({ success: false, error: 'Failed to process withdrawal request.' });
  }
});

// --- Server Start ---
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});